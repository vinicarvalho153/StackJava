public class StaticStack {
    private int top = -1;  
    private String[] data;

    public StaticStack(int size) {
        data = new String[size];  
    }

    
    public void push(String value) {
        if (top < data.length - 1) { 
            data[++top] = value;     
        } else {
            System.out.println("A pilha está cheia!");
        }
    }


    public String pop() {
        if (top >= 0) {           
            return data[top--];    
        } else {
            System.out.println("A pilha está vazia!");
            return null;
        }
    }

    public boolean isEmpty() {
        return top == -1;         
    }

    public static void main(String[] args) {
        StaticStack stack = new StaticStack(5); 
        stack.push("A");  
        stack.push("B");  
        stack.push("C");  
        System.out.println(stack.pop()); 
        stack.push("F");  
        System.out.println(stack.pop()); 
        System.out.println(stack.pop()); 
        System.out.println(stack.pop());
    }
}
